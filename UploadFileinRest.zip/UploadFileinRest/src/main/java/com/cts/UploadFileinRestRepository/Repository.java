/**
 * 
 */
/**
 * @author Aakash
 *
 */
package com.cts.UploadFileinRestRepository;



import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;



import com.cts.UploadFileinRestEntity.RestEntity;
@Transactional
public interface Repository extends  JpaRepository<RestEntity,String>{
	
	
	
}