/**
 * 
 */
/**
 * @author Aakash
 *
 */
package com.cts.UploadFileRequest;

import lombok.Data;

@Data
public class Request {
	private String inputfiles;
	private Integer id;
	
}