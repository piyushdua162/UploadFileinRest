/**
 * 
 */
/**
 * @author Aakash
 *
 */
package com.cts.UploadfileinRestController;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cts.UploadFileinRestEntity.RestEntity;
import com.cts.UploadFileinRestRepository.Repository;
@RestController

public class Controller{
	String UPLOAD_PATH = "D:/fileuplaodRest/";
	@Autowired 
	private  Repository repo;
	@RequestMapping (value="/filesupload",method = RequestMethod.POST,consumes = {"multipart/form-data"})  
	public @ResponseBody String filesUpload(@RequestParam("inputFiles") MultipartFile[] inputFiles) throws Exception{
	RestEntity tr= new RestEntity();
	tr.setInputfiles("");
	
 for (MultipartFile inputfile : inputFiles){
	if (inputfile.getOriginalFilename().equals("")){
	  tr.setInputfiles(inputfile.getOriginalFilename());
	}
	else {
		  tr.setInputfiles(tr.getInputfiles()+","+inputfile.getOriginalFilename());
		  
	  }
	byte[] bytes= inputfile.getBytes();
	Path path=Paths.get(UPLOAD_PATH+ inputfile.getOriginalFilename());
		Files.write(path, bytes);
	}
 repo.save(tr);
	
	return" filesUpload" ;
	

	
	

		
	}
	
	
	
}